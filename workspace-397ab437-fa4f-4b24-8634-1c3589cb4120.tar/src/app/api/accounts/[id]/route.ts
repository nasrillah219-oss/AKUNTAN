import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET single account
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const account = await db.account.findUnique({
      where: { id },
      include: {
        transactions: {
          take: 20,
          orderBy: { date: 'desc' },
          include: { category: true }
        }
      }
    });

    if (!account) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 });
    }

    return NextResponse.json(account);
  } catch (error) {
    console.error('Error fetching account:', error);
    return NextResponse.json({ error: 'Failed to fetch account' }, { status: 500 });
  }
}

// PUT update account
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, type, balance, icon, color, description, isActive } = body;

    const account = await db.account.update({
      where: { id },
      data: {
        name,
        type,
        balance: balance !== undefined ? parseFloat(balance) : undefined,
        icon: icon || null,
        color: color || null,
        description: description || null,
        isActive: isActive !== undefined ? isActive : undefined,
      }
    });

    return NextResponse.json(account);
  } catch (error) {
    console.error('Error updating account:', error);
    return NextResponse.json({ error: 'Failed to update account' }, { status: 500 });
  }
}

// DELETE account
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Check if account has transactions
    const transactionsCount = await db.transaction.count({
      where: { accountId: id }
    });

    if (transactionsCount > 0) {
      return NextResponse.json({ 
        error: 'Cannot delete account with existing transactions' 
      }, { status: 400 });
    }

    await db.account.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting account:', error);
    return NextResponse.json({ error: 'Failed to delete account' }, { status: 500 });
  }
}
