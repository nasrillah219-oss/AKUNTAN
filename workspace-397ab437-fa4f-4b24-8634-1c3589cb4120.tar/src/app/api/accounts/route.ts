import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all accounts
export async function GET() {
  try {
    const accounts = await db.account.findMany({
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { transactions: true }
        }
      }
    });
    return NextResponse.json(accounts);
  } catch (error) {
    console.error('Error fetching accounts:', error);
    return NextResponse.json({ error: 'Failed to fetch accounts' }, { status: 500 });
  }
}

// POST create new account
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, type, balance, icon, color, description } = body;

    const account = await db.account.create({
      data: {
        name,
        type,
        balance: parseFloat(balance) || 0,
        icon: icon || null,
        color: color || null,
        description: description || null,
      }
    });

    return NextResponse.json(account);
  } catch (error) {
    console.error('Error creating account:', error);
    return NextResponse.json({ error: 'Failed to create account' }, { status: 500 });
  }
}
