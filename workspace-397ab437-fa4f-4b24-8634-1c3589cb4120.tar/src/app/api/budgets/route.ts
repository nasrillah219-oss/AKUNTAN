import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all budgets or by month/year
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const month = searchParams.get('month');
    const year = searchParams.get('year');

    const where: Record<string, unknown> = {};

    if (month) {
      where.month = parseInt(month);
    }

    if (year) {
      where.year = parseInt(year);
    }

    const budgets = await db.budget.findMany({
      where,
      include: {
        category: true,
      },
      orderBy: [
        { year: 'desc' },
        { month: 'desc' },
      ]
    });

    return NextResponse.json(budgets);
  } catch (error) {
    console.error('Error fetching budgets:', error);
    return NextResponse.json({ error: 'Failed to fetch budgets' }, { status: 500 });
  }
}

// POST create new budget
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { categoryId, amount, month, year } = body;

    // Check if budget already exists
    const existing = await db.budget.findFirst({
      where: {
        categoryId,
        month: parseInt(month),
        year: parseInt(year),
      }
    });

    if (existing) {
      // Update existing budget
      const budget = await db.budget.update({
        where: { id: existing.id },
        data: {
          amount: parseFloat(amount),
        },
        include: { category: true }
      });
      return NextResponse.json(budget);
    }

    const budget = await db.budget.create({
      data: {
        categoryId,
        amount: parseFloat(amount),
        month: parseInt(month),
        year: parseInt(year),
      },
      include: { category: true }
    });

    return NextResponse.json(budget);
  } catch (error) {
    console.error('Error creating budget:', error);
    return NextResponse.json({ error: 'Failed to create budget' }, { status: 500 });
  }
}
