import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET dashboard stats
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const month = searchParams.get('month');
    const year = searchParams.get('year');

    const currentDate = new Date();
    const currentMonth = month ? parseInt(month) : currentDate.getMonth() + 1;
    const currentYear = year ? parseInt(year) : currentDate.getFullYear();

    // Get first and last day of month
    const startDate = new Date(currentYear, currentMonth - 1, 1);
    const endDate = new Date(currentYear, currentMonth, 0);

    // Parallel queries for efficiency
    const [
      totalIncome,
      totalExpense,
      transactions,
      accounts,
      categories,
      budgets,
      monthlyData,
    ] = await Promise.all([
      // Total income for the month
      db.transaction.aggregate({
        where: {
          type: 'income',
          date: {
            gte: startDate,
            lte: endDate,
          }
        },
        _sum: { amount: true }
      }),
      
      // Total expense for the month
      db.transaction.aggregate({
        where: {
          type: 'expense',
          date: {
            gte: startDate,
            lte: endDate,
          }
        },
        _sum: { amount: true }
      }),

      // Recent transactions
      db.transaction.findMany({
        take: 10,
        orderBy: { date: 'desc' },
        include: {
          category: true,
          account: true,
        }
      }),

      // All accounts with balances
      db.account.findMany({
        where: { isActive: true },
        orderBy: { name: 'asc' }
      }),

      // Category breakdown for the month
      db.transaction.groupBy({
        by: ['categoryId', 'type'],
        where: {
          date: {
            gte: startDate,
            lte: endDate,
          }
        },
        _sum: { amount: true }
      }),

      // Budgets for the month
      db.budget.findMany({
        where: {
          month: currentMonth,
          year: currentYear,
        },
        include: { category: true }
      }),

      // Monthly data for the last 6 months
      getMonthlyData(currentMonth, currentYear),
    ]);

    // Get category details for breakdown
    const categoryIds = [...new Set(categories.map(c => c.categoryId))];
    const categoryDetails = await db.category.findMany({
      where: { id: { in: categoryIds } }
    });

    // Combine category breakdown with details
    const categoryBreakdown = categories.map(c => ({
      ...c,
      category: categoryDetails.find(cd => cd.id === c.categoryId),
    }));

    // Calculate budget progress
    const budgetProgress = await Promise.all(
      budgets.map(async (budget) => {
        const spent = await db.transaction.aggregate({
          where: {
            categoryId: budget.categoryId,
            type: 'expense',
            date: {
              gte: startDate,
              lte: endDate,
            }
          },
          _sum: { amount: true }
        });

        return {
          ...budget,
          spent: spent._sum.amount || 0,
          remaining: budget.amount - (spent._sum.amount || 0),
          percentage: budget.amount > 0 
            ? Math.min(100, ((spent._sum.amount || 0) / budget.amount) * 100) 
            : 0,
        };
      })
    );

    // Calculate totals
    const income = totalIncome._sum.amount || 0;
    const expense = totalExpense._sum.amount || 0;
    const balance = income - expense;
    const totalAccountBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

    return NextResponse.json({
      summary: {
        income,
        expense,
        balance,
        totalAccountBalance,
      },
      recentTransactions: transactions,
      accounts,
      categoryBreakdown,
      budgetProgress,
      monthlyData,
      currentMonth,
      currentYear,
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return NextResponse.json({ error: 'Failed to fetch dashboard stats' }, { status: 500 });
  }
}

// Helper function to get monthly data for the last 6 months
async function getMonthlyData(currentMonth: number, currentYear: number) {
  const months = [];
  
  for (let i = 5; i >= 0; i--) {
    let month = currentMonth - i;
    let year = currentYear;
    
    if (month <= 0) {
      month += 12;
      year -= 1;
    }
    
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    
    const [income, expense] = await Promise.all([
      db.transaction.aggregate({
        where: {
          type: 'income',
          date: { gte: startDate, lte: endDate }
        },
        _sum: { amount: true }
      }),
      db.transaction.aggregate({
        where: {
          type: 'expense',
          date: { gte: startDate, lte: endDate }
        },
        _sum: { amount: true }
      })
    ]);
    
    months.push({
      month,
      year,
      income: income._sum.amount || 0,
      expense: expense._sum.amount || 0,
    });
  }
  
  return months;
}
