import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET single transaction
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const transaction = await db.transaction.findUnique({
      where: { id },
      include: {
        category: true,
        account: true,
      }
    });

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    return NextResponse.json(transaction);
  } catch (error) {
    console.error('Error fetching transaction:', error);
    return NextResponse.json({ error: 'Failed to fetch transaction' }, { status: 500 });
  }
}

// PUT update transaction
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { description, amount, type, date, notes, categoryId, accountId } = body;

    // Get original transaction
    const original = await db.transaction.findUnique({
      where: { id }
    });

    if (!original) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    const result = await db.$transaction(async (tx) => {
      // Revert original account balance
      const originalBalanceChange = original.type === 'income' ? -original.amount : original.amount;
      await tx.account.update({
        where: { id: original.accountId },
        data: {
          balance: {
            increment: originalBalanceChange
          }
        }
      });

      // Update transaction
      const transaction = await tx.transaction.update({
        where: { id },
        data: {
          description,
          amount: parseFloat(amount),
          type,
          date: new Date(date),
          notes: notes || null,
          categoryId,
          accountId,
        },
        include: {
          category: true,
          account: true,
        }
      });

      // Apply new account balance
      const newBalanceChange = type === 'income' ? parseFloat(amount) : -parseFloat(amount);
      await tx.account.update({
        where: { id: accountId },
        data: {
          balance: {
            increment: newBalanceChange
          }
        }
      });

      return transaction;
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error updating transaction:', error);
    return NextResponse.json({ error: 'Failed to update transaction' }, { status: 500 });
  }
}

// DELETE transaction
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const result = await db.$transaction(async (tx) => {
      // Get transaction to delete
      const transaction = await tx.transaction.findUnique({
        where: { id }
      });

      if (!transaction) {
        throw new Error('Transaction not found');
      }

      // Revert account balance
      const balanceChange = transaction.type === 'income' ? -transaction.amount : transaction.amount;
      await tx.account.update({
        where: { id: transaction.accountId },
        data: {
          balance: {
            increment: balanceChange
          }
        }
      });

      // Delete transaction
      await tx.transaction.delete({
        where: { id }
      });

      return { success: true };
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error deleting transaction:', error);
    return NextResponse.json({ error: 'Failed to delete transaction' }, { status: 500 });
  }
}
