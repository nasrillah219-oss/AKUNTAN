import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all transactions
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const categoryId = searchParams.get('categoryId');
    const accountId = searchParams.get('accountId');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const limit = searchParams.get('limit');
    const page = searchParams.get('page') || '1';

    const where: Record<string, unknown> = {};

    if (type && (type === 'income' || type === 'expense')) {
      where.type = type;
    }

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (accountId) {
      where.accountId = accountId;
    }

    if (startDate || endDate) {
      where.date = {};
      if (startDate) {
        (where.date as Record<string, unknown>).gte = new Date(startDate);
      }
      if (endDate) {
        (where.date as Record<string, unknown>).lte = new Date(endDate);
      }
    }

    const take = limit ? parseInt(limit) : 50;
    const skip = (parseInt(page) - 1) * take;

    const [transactions, total] = await Promise.all([
      db.transaction.findMany({
        where,
        include: {
          category: true,
          account: true,
        },
        orderBy: { date: 'desc' },
        take,
        skip,
      }),
      db.transaction.count({ where }),
    ]);

    return NextResponse.json({
      transactions,
      pagination: {
        total,
        page: parseInt(page),
        limit: take,
        totalPages: Math.ceil(total / take),
      }
    });
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return NextResponse.json({ error: 'Failed to fetch transactions' }, { status: 500 });
  }
}

// POST create new transaction
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { description, amount, type, date, notes, categoryId, accountId } = body;

    // Create transaction and update account balance
    const result = await db.$transaction(async (tx) => {
      const transaction = await tx.transaction.create({
        data: {
          description,
          amount: parseFloat(amount),
          type,
          date: new Date(date),
          notes: notes || null,
          categoryId,
          accountId,
        },
        include: {
          category: true,
          account: true,
        }
      });

      // Update account balance
      const balanceChange = type === 'income' ? parseFloat(amount) : -parseFloat(amount);
      await tx.account.update({
        where: { id: accountId },
        data: {
          balance: {
            increment: balanceChange
          }
        }
      });

      return transaction;
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error creating transaction:', error);
    return NextResponse.json({ error: 'Failed to create transaction' }, { status: 500 });
  }
}
