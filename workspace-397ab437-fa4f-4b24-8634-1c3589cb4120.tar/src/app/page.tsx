'use client';

import { useState, useEffect, useCallback } from 'react';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  ArrowDownCircle,
  ArrowUpCircle,
  Tags,
  PieChart,
  Wallet,
  Plus,
  Trash2,
  Edit,
  Search,
  TrendingUp,
  TrendingDown,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Building2,
  CreditCard,
  Banknote,
  Smartphone,
  MoreHorizontal,
  Eye,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';

import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

// Types
interface Category {
  id: string;
  name: string;
  type: 'income' | 'expense';
  icon: string | null;
  color: string | null;
  _count?: { transactions: number };
}

interface Account {
  id: string;
  name: string;
  type: string;
  balance: number;
  icon: string | null;
  color: string | null;
  _count?: { transactions: number };
}

interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  date: string;
  notes: string | null;
  categoryId: string;
  accountId: string;
  category: Category;
  account: Account;
}

interface Budget {
  id: string;
  categoryId: string;
  amount: number;
  month: number;
  year: number;
  category: Category;
  spent?: number;
  remaining?: number;
  percentage?: number;
}

interface DashboardData {
  summary: {
    income: number;
    expense: number;
    balance: number;
    totalAccountBalance: number;
  };
  recentTransactions: Transaction[];
  accounts: Account[];
  categoryBreakdown: Array<{
    categoryId: string;
    type: string;
    _sum: { amount: number };
    category: Category;
  }>;
  budgetProgress: Budget[];
  monthlyData: Array<{
    month: number;
    year: number;
    income: number;
    expense: number;
  }>;
  currentMonth: number;
  currentYear: number;
}

// Currency formatter
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

// Get month name
const getMonthName = (month: number) => {
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  return months[month - 1];
};

// Account type icons
const getAccountIcon = (type: string) => {
  switch (type) {
    case 'cash': return Banknote;
    case 'bank': return Building2;
    case 'ewallet': return Smartphone;
    case 'credit_card': return CreditCard;
    default: return Wallet;
  }
};

// Category colors
const categoryColors = [
  'bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-yellow-500',
  'bg-lime-500', 'bg-green-500', 'bg-emerald-500', 'bg-teal-500',
  'bg-cyan-500', 'bg-sky-500', 'bg-blue-500', 'bg-indigo-500',
  'bg-violet-500', 'bg-purple-500', 'bg-fuchsia-500', 'bg-pink-500',
];

export default function AccountingApp() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  
  // Data states
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  
  // Dialog states
  const [transactionDialogOpen, setTransactionDialogOpen] = useState(false);
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [accountDialogOpen, setAccountDialogOpen] = useState(false);
  const [budgetDialogOpen, setBudgetDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editItem, setEditItem] = useState<Transaction | Category | Account | null>(null);
  const [deleteType, setDeleteType] = useState<'transaction' | 'category' | 'account' | 'budget' | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  // Form states
  const [transactionForm, setTransactionForm] = useState({
    description: '',
    amount: '',
    type: 'expense' as 'income' | 'expense',
    date: format(new Date(), 'yyyy-MM-dd'),
    notes: '',
    categoryId: '',
    accountId: '',
  });
  
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    type: 'expense' as 'income' | 'expense',
    icon: '',
    color: categoryColors[0],
  });
  
  const [accountForm, setAccountForm] = useState({
    name: '',
    type: 'cash',
    balance: '0',
    icon: '',
    color: categoryColors[0],
    description: '',
  });
  
  const [budgetForm, setBudgetForm] = useState({
    categoryId: '',
    amount: '',
    month: currentMonth,
    year: currentYear,
  });
  
  // Search and filter
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');

  // Fetch data functions
  const fetchDashboard = useCallback(async () => {
    try {
      const res = await fetch(`/api/dashboard?month=${currentMonth}&year=${currentYear}`);
      const data = await res.json();
      setDashboardData(data);
    } catch {
      toast.error('Gagal memuat data dashboard');
    }
  }, [currentMonth, currentYear]);

  const fetchTransactions = useCallback(async () => {
    try {
      const res = await fetch('/api/transactions');
      const data = await res.json();
      setTransactions(data.transactions || []);
    } catch {
      toast.error('Gagal memuat data transaksi');
    }
  }, []);

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/categories');
      const data = await res.json();
      setCategories(data);
    } catch {
      toast.error('Gagal memuat data kategori');
    }
  }, []);

  const fetchAccounts = useCallback(async () => {
    try {
      const res = await fetch('/api/accounts');
      const data = await res.json();
      setAccounts(data);
    } catch {
      toast.error('Gagal memuat data akun');
    }
  }, []);

  const fetchBudgets = useCallback(async () => {
    try {
      const res = await fetch(`/api/budgets?month=${currentMonth}&year=${currentYear}`);
      const data = await res.json();
      setBudgets(data);
    } catch {
      toast.error('Gagal memuat data anggaran');
    }
  }, [currentMonth, currentYear]);

  // Initial fetch
  useEffect(() => {
    fetchDashboard();
    fetchTransactions();
    fetchCategories();
    fetchAccounts();
    fetchBudgets();
  }, [fetchDashboard, fetchTransactions, fetchCategories, fetchAccounts, fetchBudgets]);

  // Seed default data if empty
  useEffect(() => {
    const seedDefaultData = async () => {
      if (categories.length === 0) {
        const defaultCategories = [
          { name: 'Gaji', type: 'income', color: 'bg-green-500' },
          { name: 'Investasi', type: 'income', color: 'bg-emerald-500' },
          { name: 'Bonus', type: 'income', color: 'bg-teal-500' },
          { name: 'Lainnya', type: 'income', color: 'bg-cyan-500' },
          { name: 'Makanan', type: 'expense', color: 'bg-red-500' },
          { name: 'Transportasi', type: 'expense', color: 'bg-orange-500' },
          { name: 'Belanja', type: 'expense', color: 'bg-amber-500' },
          { name: 'Tagihan', type: 'expense', color: 'bg-yellow-500' },
          { name: 'Hiburan', type: 'expense', color: 'bg-pink-500' },
          { name: 'Kesehatan', type: 'expense', color: 'bg-purple-500' },
          { name: 'Pendidikan', type: 'expense', color: 'bg-violet-500' },
        ];
        
        for (const cat of defaultCategories) {
          await fetch('/api/categories', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cat),
          });
        }
        fetchCategories();
      }
      
      if (accounts.length === 0) {
        const defaultAccounts = [
          { name: 'Kas', type: 'cash', balance: 0, color: 'bg-green-500' },
          { name: 'Bank BCA', type: 'bank', balance: 0, color: 'bg-blue-500' },
        ];
        
        for (const acc of defaultAccounts) {
          await fetch('/api/accounts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(acc),
          });
        }
        fetchAccounts();
      }
    };
    
    seedDefaultData();
  }, [categories.length, accounts.length, fetchCategories, fetchAccounts]);

  // CRUD handlers
  const handleAddTransaction = async () => {
    if (!transactionForm.description || !transactionForm.amount || !transactionForm.categoryId || !transactionForm.accountId) {
      toast.error('Mohon lengkapi semua field yang diperlukan');
      return;
    }

    try {
      if (editItem && 'amount' in editItem) {
        await fetch(`/api/transactions/${editItem.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(transactionForm),
        });
        toast.success('Transaksi berhasil diperbarui');
      } else {
        await fetch('/api/transactions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(transactionForm),
        });
        toast.success('Transaksi berhasil ditambahkan');
      }
      
      setTransactionDialogOpen(false);
      setEditItem(null);
      setTransactionForm({
        description: '',
        amount: '',
        type: 'expense',
        date: format(new Date(), 'yyyy-MM-dd'),
        notes: '',
        categoryId: '',
        accountId: '',
      });
      fetchDashboard();
      fetchTransactions();
      fetchAccounts();
    } catch {
      toast.error('Gagal menyimpan transaksi');
    }
  };

  const handleAddCategory = async () => {
    if (!categoryForm.name) {
      toast.error('Nama kategori tidak boleh kosong');
      return;
    }

    try {
      if (editItem && 'type' in editItem && !('amount' in editItem)) {
        await fetch(`/api/categories/${editItem.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(categoryForm),
        });
        toast.success('Kategori berhasil diperbarui');
      } else {
        await fetch('/api/categories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(categoryForm),
        });
        toast.success('Kategori berhasil ditambahkan');
      }
      
      setCategoryDialogOpen(false);
      setEditItem(null);
      setCategoryForm({ name: '', type: 'expense', icon: '', color: categoryColors[0] });
      fetchCategories();
    } catch {
      toast.error('Gagal menyimpan kategori');
    }
  };

  const handleAddAccount = async () => {
    if (!accountForm.name) {
      toast.error('Nama akun tidak boleh kosong');
      return;
    }

    try {
      if (editItem && 'balance' in editItem && !('amount' in editItem)) {
        await fetch(`/api/accounts/${editItem.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(accountForm),
        });
        toast.success('Akun berhasil diperbarui');
      } else {
        await fetch('/api/accounts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(accountForm),
        });
        toast.success('Akun berhasil ditambahkan');
      }
      
      setAccountDialogOpen(false);
      setEditItem(null);
      setAccountForm({ name: '', type: 'cash', balance: '0', icon: '', color: categoryColors[0], description: '' });
      fetchAccounts();
      fetchDashboard();
    } catch {
      toast.error('Gagal menyimpan akun');
    }
  };

  const handleAddBudget = async () => {
    if (!budgetForm.categoryId || !budgetForm.amount) {
      toast.error('Mohon lengkapi semua field yang diperlukan');
      return;
    }

    try {
      await fetch('/api/budgets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...budgetForm, month: currentMonth, year: currentYear }),
      });
      toast.success('Anggaran berhasil disimpan');
      setBudgetDialogOpen(false);
      setBudgetForm({ categoryId: '', amount: '', month: currentMonth, year: currentYear });
      fetchBudgets();
      fetchDashboard();
    } catch {
      toast.error('Gagal menyimpan anggaran');
    }
  };

  const handleDelete = async () => {
    if (!deleteType || !deleteId) return;

    try {
      const res = await fetch(`/api/${deleteType}s/${deleteId}`, {
        method: 'DELETE',
      });
      
      const data = await res.json();
      
      if (data.error) {
        toast.error(data.error);
        return;
      }
      
      toast.success('Data berhasil dihapus');
      
      switch (deleteType) {
        case 'transaction':
          fetchTransactions();
          fetchDashboard();
          fetchAccounts();
          break;
        case 'category':
          fetchCategories();
          break;
        case 'account':
          fetchAccounts();
          fetchDashboard();
          break;
        case 'budget':
          fetchBudgets();
          fetchDashboard();
          break;
      }
    } catch {
      toast.error('Gagal menghapus data');
    } finally {
      setDeleteDialogOpen(false);
      setDeleteType(null);
      setDeleteId(null);
    }
  };

  // Navigation items
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'transactions', label: 'Transaksi', icon: ArrowDownCircle },
    { id: 'categories', label: 'Kategori', icon: Tags },
    { id: 'accounts', label: 'Akun', icon: Wallet },
    { id: 'budgets', label: 'Anggaran', icon: PieChart },
    { id: 'reports', label: 'Laporan', icon: TrendingUp },
  ];

  // Filtered transactions
  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = t.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || t.type === filterType;
    return matchesSearch && matchesType;
  });

  // Get income/expense categories
  const incomeCategories = categories.filter(c => c.type === 'income');
  const expenseCategories = categories.filter(c => c.type === 'expense');

  // Change month
  const changeMonth = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      if (currentMonth === 1) {
        setCurrentMonth(12);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
    } else {
      if (currentMonth === 12) {
        setCurrentMonth(1);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 z-40 flex items-center justify-between px-4">
        <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)}>
          <Menu className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-bold text-gray-900 dark:text-white">Akuntansi</h1>
        <Button 
          size="icon" 
          onClick={() => {
            setEditItem(null);
            setTransactionForm({
              description: '',
              amount: '',
              type: 'expense',
              date: format(new Date(), 'yyyy-MM-dd'),
              notes: '',
              categoryId: '',
              accountId: '',
            });
            setTransactionDialogOpen(true);
          }}
        >
          <Plus className="h-5 w-5" />
        </Button>
      </div>

      {/* Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="lg:hidden fixed inset-0 bg-black/50 z-40"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence>
        <motion.aside
          initial={{ x: -280 }}
          animate={{ x: sidebarOpen ? 0 : 0 }}
          className={cn(
            "fixed top-0 left-0 h-full w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 z-50",
            "lg:translate-x-0 transition-transform duration-300",
            sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
          )}
        >
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
                <Wallet className="h-4 w-4 text-white" />
              </div>
              <span className="font-bold text-lg text-gray-900 dark:text-white">Akuntansi</span>
            </div>
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(false)}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <ScrollArea className="flex-1 p-4">
            <nav className="space-y-1">
              {navItems.map(item => (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? 'secondary' : 'ghost'}
                  className={cn(
                    "w-full justify-start gap-3",
                    activeTab === item.id && "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400"
                  )}
                  onClick={() => {
                    setActiveTab(item.id);
                    setSidebarOpen(false);
                  }}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              ))}
            </nav>
          </ScrollArea>
          
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
              © 2024 Akuntansi App
            </p>
          </div>
        </motion.aside>
      </AnimatePresence>

      {/* Main Content */}
      <main className="lg:pl-64 pt-16 lg:pt-0">
        <div className="p-4 lg:p-6">
          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Month Selector */}
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h2>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={() => changeMonth('prev')}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                    <span className="font-medium text-gray-900 dark:text-white">
                      {getMonthName(currentMonth)} {currentYear}
                    </span>
                  </div>
                  <Button variant="outline" size="icon" onClick={() => changeMonth('next')}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white border-0">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-emerald-100 text-sm">Pemasukan</p>
                        <p className="text-xl font-bold mt-1">
                          {formatCurrency(dashboardData?.summary.income || 0)}
                        </p>
                      </div>
                      <ArrowUpCircle className="h-8 w-8 text-emerald-200" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white border-0">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-red-100 text-sm">Pengeluaran</p>
                        <p className="text-xl font-bold mt-1">
                          {formatCurrency(dashboardData?.summary.expense || 0)}
                        </p>
                      </div>
                      <ArrowDownCircle className="h-8 w-8 text-red-200" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-100 text-sm">Saldo Bulan Ini</p>
                        <p className={cn(
                          "text-xl font-bold mt-1",
                          (dashboardData?.summary.balance || 0) < 0 && "text-yellow-200"
                        )}>
                          {formatCurrency(dashboardData?.summary.balance || 0)}
                        </p>
                      </div>
                      {(dashboardData?.summary.balance || 0) >= 0 ? 
                        <TrendingUp className="h-8 w-8 text-blue-200" /> :
                        <TrendingDown className="h-8 w-8 text-yellow-200" />
                      }
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-100 text-sm">Total Saldo</p>
                        <p className="text-xl font-bold mt-1">
                          {formatCurrency(dashboardData?.summary.totalAccountBalance || 0)}
                        </p>
                      </div>
                      <Wallet className="h-8 w-8 text-purple-200" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Accounts */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-lg">Akun Keuangan</CardTitle>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => {
                        setEditItem(null);
                        setAccountForm({ name: '', type: 'cash', balance: '0', icon: '', color: categoryColors[0], description: '' });
                        setAccountDialogOpen(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" /> Tambah
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-48">
                      <div className="space-y-3">
                        {dashboardData?.accounts.map(account => {
                          const Icon = getAccountIcon(account.type);
                          return (
                            <div key={account.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                              <div className="flex items-center gap-3">
                                <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", account.color || "bg-gray-500")}>
                                  <Icon className="h-5 w-5 text-white" />
                                </div>
                                <div>
                                  <p className="font-medium text-gray-900 dark:text-white">{account.name}</p>
                                  <p className="text-xs text-gray-500 capitalize">{account.type.replace('_', ' ')}</p>
                                </div>
                              </div>
                              <p className={cn(
                                "font-semibold",
                                account.balance >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"
                              )}>
                                {formatCurrency(account.balance)}
                              </p>
                            </div>
                          );
                        })}
                        {(!dashboardData?.accounts || dashboardData.accounts.length === 0) && (
                          <p className="text-center text-gray-500 py-4">Belum ada akun</p>
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>

                {/* Recent Transactions */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-lg">Transaksi Terbaru</CardTitle>
                    <Button variant="outline" size="sm" onClick={() => setActiveTab('transactions')}>
                      <Eye className="h-4 w-4 mr-1" /> Lihat Semua
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-48">
                      <div className="space-y-3">
                        {dashboardData?.recentTransactions.map(transaction => (
                          <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-10 h-10 rounded-full flex items-center justify-center",
                                transaction.type === 'income' ? "bg-emerald-100 dark:bg-emerald-900/30" : "bg-red-100 dark:bg-red-900/30"
                              )}>
                                {transaction.type === 'income' ? 
                                  <ArrowUpCircle className="h-5 w-5 text-emerald-600 dark:text-emerald-400" /> :
                                  <ArrowDownCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                                }
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white text-sm">{transaction.description}</p>
                                <p className="text-xs text-gray-500">{transaction.category?.name}</p>
                              </div>
                            </div>
                            <p className={cn(
                              "font-semibold text-sm",
                              transaction.type === 'income' ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"
                            )}>
                              {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                            </p>
                          </div>
                        ))}
                        {(!dashboardData?.recentTransactions || dashboardData.recentTransactions.length === 0) && (
                          <p className="text-center text-gray-500 py-4">Belum ada transaksi</p>
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>

              {/* Budget Progress */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-lg">Progres Anggaran</CardTitle>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setBudgetForm({ categoryId: '', amount: '', month: currentMonth, year: currentYear });
                      setBudgetDialogOpen(true);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" /> Tambah
                  </Button>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-48">
                    <div className="space-y-4">
                      {dashboardData?.budgetProgress.map(budget => (
                        <div key={budget.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className={cn("w-3 h-3 rounded-full", budget.category.color || "bg-gray-500")} />
                              <span className="font-medium text-gray-900 dark:text-white">{budget.category.name}</span>
                            </div>
                            <div className="text-sm">
                              <span className="text-gray-500">
                                {formatCurrency(budget.spent || 0)} / {formatCurrency(budget.amount)}
                              </span>
                            </div>
                          </div>
                          <Progress 
                            value={budget.percentage || 0} 
                            className={cn(
                              "h-2",
                              (budget.percentage || 0) >= 100 && "[&>div]:bg-red-500",
                              (budget.percentage || 0) >= 80 && (budget.percentage || 0) < 100 && "[&>div]:bg-yellow-500"
                            )}
                          />
                          <div className="flex items-center justify-between text-xs">
                            <span className={cn(
                              (budget.percentage || 0) >= 100 ? "text-red-500" : "text-gray-500"
                            )}>
                              {(budget.percentage || 0).toFixed(0)}% digunakan
                            </span>
                            <span className={cn(
                              (budget.remaining || 0) < 0 ? "text-red-500" : "text-emerald-500"
                            )}>
                              Sisa: {formatCurrency(budget.remaining || 0)}
                            </span>
                          </div>
                        </div>
                      ))}
                      {(!dashboardData?.budgetProgress || dashboardData.budgetProgress.length === 0) && (
                        <p className="text-center text-gray-500 py-4">Belum ada anggaran</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Quick Add Transaction FAB */}
              <div className="fixed bottom-6 right-6 lg:hidden">
                <Button 
                  size="lg" 
                  className="rounded-full w-14 h-14 shadow-lg"
                  onClick={() => {
                    setEditItem(null);
                    setTransactionForm({
                      description: '',
                      amount: '',
                      type: 'expense',
                      date: format(new Date(), 'yyyy-MM-dd'),
                      notes: '',
                      categoryId: '',
                      accountId: '',
                    });
                    setTransactionDialogOpen(true);
                  }}
                >
                  <Plus className="h-6 w-6" />
                </Button>
              </div>
            </div>
          )}

          {/* Transactions Tab */}
          {activeTab === 'transactions' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Transaksi</h2>
                <Button 
                  onClick={() => {
                    setEditItem(null);
                    setTransactionForm({
                      description: '',
                      amount: '',
                      type: 'expense',
                      date: format(new Date(), 'yyyy-MM-dd'),
                      notes: '',
                      categoryId: '',
                      accountId: '',
                    });
                    setTransactionDialogOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" /> Tambah Transaksi
                </Button>
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Cari transaksi..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={filterType} onValueChange={(v) => setFilterType(v as typeof filterType)}>
                  <SelectTrigger className="w-full sm:w-40">
                    <SelectValue placeholder="Filter tipe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua</SelectItem>
                    <SelectItem value="income">Pemasukan</SelectItem>
                    <SelectItem value="expense">Pengeluaran</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Transactions List */}
              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="h-[calc(100vh-320px)]">
                    <div className="divide-y divide-gray-200 dark:divide-gray-700">
                      {filteredTransactions.map(transaction => (
                        <div key={transaction.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-12 h-12 rounded-full flex items-center justify-center",
                                transaction.type === 'income' ? "bg-emerald-100 dark:bg-emerald-900/30" : "bg-red-100 dark:bg-red-900/30"
                              )}>
                                {transaction.type === 'income' ? 
                                  <ArrowUpCircle className="h-6 w-6 text-emerald-600 dark:text-emerald-400" /> :
                                  <ArrowDownCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
                                }
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">{transaction.description}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    {transaction.category?.name}
                                  </Badge>
                                  <span className="text-xs text-gray-500">•</span>
                                  <span className="text-xs text-gray-500">
                                    {format(new Date(transaction.date), 'd MMM yyyy', { locale: id })}
                                  </span>
                                  <span className="text-xs text-gray-500">•</span>
                                  <span className="text-xs text-gray-500">{transaction.account?.name}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <p className={cn(
                                "font-bold text-lg mr-2",
                                transaction.type === 'income' ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"
                              )}>
                                {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                              </p>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditItem(transaction);
                                  setTransactionForm({
                                    description: transaction.description,
                                    amount: transaction.amount.toString(),
                                    type: transaction.type,
                                    date: format(new Date(transaction.date), 'yyyy-MM-dd'),
                                    notes: transaction.notes || '',
                                    categoryId: transaction.categoryId,
                                    accountId: transaction.accountId,
                                  });
                                  setTransactionDialogOpen(true);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setDeleteType('transaction');
                                  setDeleteId(transaction.id);
                                  setDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                      {filteredTransactions.length === 0 && (
                        <div className="p-8 text-center text-gray-500">
                          Tidak ada transaksi ditemukan
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Categories Tab */}
          {activeTab === 'categories' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Kategori</h2>
                <Button 
                  onClick={() => {
                    setEditItem(null);
                    setCategoryForm({ name: '', type: 'expense', icon: '', color: categoryColors[0] });
                    setCategoryDialogOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" /> Tambah Kategori
                </Button>
              </div>

              <Tabs defaultValue="expense" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="expense">Pengeluaran</TabsTrigger>
                  <TabsTrigger value="income">Pemasukan</TabsTrigger>
                </TabsList>
                <TabsContent value="expense" className="mt-4">
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {expenseCategories.map(category => (
                      <Card key={category.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={cn("w-10 h-10 rounded-full", category.color || "bg-gray-500")} />
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">{category.name}</p>
                                <p className="text-xs text-gray-500">{category._count?.transactions || 0} transaksi</p>
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditItem(category);
                                  setCategoryForm({
                                    name: category.name,
                                    type: category.type,
                                    icon: category.icon || '',
                                    color: category.color || categoryColors[0],
                                  });
                                  setCategoryDialogOpen(true);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setDeleteType('category');
                                  setDeleteId(category.id);
                                  setDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="income" className="mt-4">
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {incomeCategories.map(category => (
                      <Card key={category.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={cn("w-10 h-10 rounded-full", category.color || "bg-gray-500")} />
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">{category.name}</p>
                                <p className="text-xs text-gray-500">{category._count?.transactions || 0} transaksi</p>
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditItem(category);
                                  setCategoryForm({
                                    name: category.name,
                                    type: category.type,
                                    icon: category.icon || '',
                                    color: category.color || categoryColors[0],
                                  });
                                  setCategoryDialogOpen(true);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setDeleteType('category');
                                  setDeleteId(category.id);
                                  setDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Accounts Tab */}
          {activeTab === 'accounts' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Akun Keuangan</h2>
                <Button 
                  onClick={() => {
                    setEditItem(null);
                    setAccountForm({ name: '', type: 'cash', balance: '0', icon: '', color: categoryColors[0], description: '' });
                    setAccountDialogOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" /> Tambah Akun
                </Button>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {accounts.map(account => {
                  const Icon = getAccountIcon(account.type);
                  return (
                    <Card key={account.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className={cn("w-12 h-12 rounded-full flex items-center justify-center", account.color || "bg-gray-500")}>
                              <Icon className="h-6 w-6 text-white" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">{account.name}</p>
                              <p className="text-xs text-gray-500 capitalize">{account.type.replace('_', ' ')}</p>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => {
                                setEditItem(account);
                                setAccountForm({
                                  name: account.name,
                                  type: account.type,
                                  balance: account.balance.toString(),
                                  icon: account.icon || '',
                                  color: account.color || categoryColors[0],
                                  description: account.description || '',
                                });
                                setAccountDialogOpen(true);
                              }}>
                                <Edit className="h-4 w-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="text-red-600"
                                onClick={() => {
                                  setDeleteType('account');
                                  setDeleteId(account.id);
                                  setDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 mr-2" /> Hapus
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        <Separator className="my-3" />
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Saldo</span>
                          <span className={cn(
                            "text-lg font-bold",
                            account.balance >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"
                          )}>
                            {formatCurrency(account.balance)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          {account._count?.transactions || 0} transaksi
                        </p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}

          {/* Budgets Tab */}
          {activeTab === 'budgets' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Anggaran</h2>
                <Button 
                  onClick={() => {
                    setBudgetForm({ categoryId: '', amount: '', month: currentMonth, year: currentYear });
                    setBudgetDialogOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" /> Tambah Anggaran
                </Button>
              </div>

              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Anggaran Bulan {getMonthName(currentMonth)} {currentYear}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => changeMonth('prev')}>
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" onClick={() => changeMonth('next')}>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {budgets.map(budget => {
                      const spent = dashboardData?.budgetProgress.find(b => b.id === budget.id)?.spent || 0;
                      const percentage = budget.amount > 0 ? (spent / budget.amount) * 100 : 0;
                      const remaining = budget.amount - spent;
                      
                      return (
                        <div key={budget.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className={cn("w-4 h-4 rounded-full", budget.category.color || "bg-gray-500")} />
                              <span className="font-medium text-gray-900 dark:text-white">{budget.category.name}</span>
                            </div>
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <p className="text-sm text-gray-500">
                                  {formatCurrency(spent)} / {formatCurrency(budget.amount)}
                                </p>
                              </div>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    setEditItem(budget);
                                    setBudgetForm({
                                      categoryId: budget.categoryId,
                                      amount: budget.amount.toString(),
                                      month: budget.month,
                                      year: budget.year,
                                    });
                                    setBudgetDialogOpen(true);
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    setDeleteType('budget');
                                    setDeleteId(budget.id);
                                    setDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                            </div>
                          </div>
                          <Progress 
                            value={Math.min(percentage, 100)} 
                            className={cn(
                              "h-3",
                              percentage >= 100 && "[&>div]:bg-red-500",
                              percentage >= 80 && percentage < 100 && "[&>div]:bg-yellow-500"
                            )}
                          />
                          <div className="flex items-center justify-between text-sm">
                            <span className={cn(
                              "flex items-center gap-1",
                              percentage >= 100 ? "text-red-500" : percentage >= 80 ? "text-yellow-500" : "text-gray-500"
                            )}>
                              {percentage >= 100 ? (
                                <>
                                  <AlertCircle className="h-4 w-4" /> Melebihi anggaran!
                                </>
                              ) : percentage >= 80 ? (
                                <>
                                  <AlertCircle className="h-4 w-4" /> Mendekati batas
                                </>
                              ) : (
                                <>
                                  <CheckCircle className="h-4 w-4" /> {percentage.toFixed(0)}% digunakan
                                </>
                              )}
                            </span>
                            <span className={cn(
                              remaining < 0 ? "text-red-500" : "text-emerald-500"
                            )}>
                              Sisa: {formatCurrency(remaining)}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                    {budgets.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        Belum ada anggaran untuk bulan ini
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Reports Tab */}
          {activeTab === 'reports' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Laporan Keuangan</h2>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={() => changeMonth('prev')}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                    <span className="font-medium text-gray-900 dark:text-white">
                      {getMonthName(currentMonth)} {currentYear}
                    </span>
                  </div>
                  <Button variant="outline" size="icon" onClick={() => changeMonth('next')}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Monthly Summary */}
              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Tren 6 Bulan Terakhir</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 flex items-end gap-2">
                      {dashboardData?.monthlyData.map((data, index) => (
                        <div key={index} className="flex-1 flex flex-col items-center gap-2">
                          <div className="w-full flex gap-1 justify-center items-end h-48">
                            <div 
                              className="w-4 bg-emerald-500 rounded-t"
                              style={{ height: `${Math.min((data.income / Math.max(...(dashboardData?.monthlyData.map(d => Math.max(d.income, d.expense)) || [1]))) * 100, 100)}%` }}
                            />
                            <div 
                              className="w-4 bg-red-500 rounded-t"
                              style={{ height: `${Math.min((data.expense / Math.max(...(dashboardData?.monthlyData.map(d => Math.max(d.income, d.expense)) || [1]))) * 100, 100)}%` }}
                            />
                          </div>
                          <span className="text-xs text-gray-500">
                            {getMonthName(data.month).substring(0, 3)}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-center gap-6 mt-4">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded bg-emerald-500" />
                        <span className="text-sm text-gray-500">Pemasukan</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded bg-red-500" />
                        <span className="text-sm text-gray-500">Pengeluaran</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Ringkasan Bulan Ini</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <ArrowUpCircle className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                            <span className="text-gray-700 dark:text-gray-300">Total Pemasukan</span>
                          </div>
                          <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(dashboardData?.summary.income || 0)}
                          </span>
                        </div>
                      </div>
                      <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <ArrowDownCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                            <span className="text-gray-700 dark:text-gray-300">Total Pengeluaran</span>
                          </div>
                          <span className="text-lg font-bold text-red-600 dark:text-red-400">
                            {formatCurrency(dashboardData?.summary.expense || 0)}
                          </span>
                        </div>
                      </div>
                      <Separator />
                      <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                            <span className="text-gray-700 dark:text-gray-300">Saldo Bersih</span>
                          </div>
                          <span className={cn(
                            "text-lg font-bold",
                            (dashboardData?.summary.balance || 0) >= 0 
                              ? "text-emerald-600 dark:text-emerald-400" 
                              : "text-red-600 dark:text-red-400"
                          )}>
                            {formatCurrency(dashboardData?.summary.balance || 0)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Category Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle>Pengeluaran per Kategori</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData?.categoryBreakdown
                      .filter(c => c.type === 'expense')
                      .sort((a, b) => (b._sum.amount || 0) - (a._sum.amount || 0))
                      .map((cat, index) => {
                        const totalExpense = dashboardData?.categoryBreakdown
                          .filter(c => c.type === 'expense')
                          .reduce((sum, c) => sum + (c._sum.amount || 0), 0) || 1;
                        const percentage = ((cat._sum.amount || 0) / totalExpense) * 100;
                        
                        return (
                          <div key={index} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className={cn("w-4 h-4 rounded-full", cat.category?.color || "bg-gray-500")} />
                                <span className="font-medium text-gray-900 dark:text-white">{cat.category?.name}</span>
                              </div>
                              <div className="text-right">
                                <span className="font-medium">{formatCurrency(cat._sum.amount || 0)}</span>
                                <span className="text-gray-500 ml-2">({percentage.toFixed(1)}%)</span>
                              </div>
                            </div>
                            <Progress value={percentage} className="h-2" />
                          </div>
                        );
                      })}
                    {dashboardData?.categoryBreakdown.filter(c => c.type === 'expense').length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        Belum ada data pengeluaran
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>

      {/* Transaction Dialog */}
      <Dialog open={transactionDialogOpen} onOpenChange={setTransactionDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editItem && 'amount' in editItem ? 'Edit Transaksi' : 'Tambah Transaksi'}</DialogTitle>
            <DialogDescription>
              {editItem && 'amount' in editItem ? 'Perbarui detail transaksi' : 'Tambahkan transaksi baru'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Tipe Transaksi</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={transactionForm.type === 'income' ? 'default' : 'outline'}
                  className={cn("flex-1", transactionForm.type === 'income' && "bg-emerald-500 hover:bg-emerald-600")}
                  onClick={() => setTransactionForm({ ...transactionForm, type: 'income' })}
                >
                  <ArrowUpCircle className="h-4 w-4 mr-2" /> Pemasukan
                </Button>
                <Button
                  type="button"
                  variant={transactionForm.type === 'expense' ? 'default' : 'outline'}
                  className={cn("flex-1", transactionForm.type === 'expense' && "bg-red-500 hover:bg-red-600")}
                  onClick={() => setTransactionForm({ ...transactionForm, type: 'expense' })}
                >
                  <ArrowDownCircle className="h-4 w-4 mr-2" /> Pengeluaran
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Deskripsi</Label>
              <Input
                id="description"
                placeholder="Masukkan deskripsi"
                value={transactionForm.description}
                onChange={(e) => setTransactionForm({ ...transactionForm, description: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">Jumlah (Rp)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0"
                value={transactionForm.amount}
                onChange={(e) => setTransactionForm({ ...transactionForm, amount: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Tanggal</Label>
              <Input
                id="date"
                type="date"
                value={transactionForm.date}
                onChange={(e) => setTransactionForm({ ...transactionForm, date: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Kategori</Label>
              <Select
                value={transactionForm.categoryId}
                onValueChange={(v) => setTransactionForm({ ...transactionForm, categoryId: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih kategori" />
                </SelectTrigger>
                <SelectContent>
                  {(transactionForm.type === 'income' ? incomeCategories : expenseCategories).map(cat => (
                    <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Akun</Label>
              <Select
                value={transactionForm.accountId}
                onValueChange={(v) => setTransactionForm({ ...transactionForm, accountId: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih akun" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map(acc => (
                    <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Catatan (Opsional)</Label>
              <Textarea
                id="notes"
                placeholder="Tambahkan catatan..."
                value={transactionForm.notes}
                onChange={(e) => setTransactionForm({ ...transactionForm, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTransactionDialogOpen(false)}>Batal</Button>
            <Button onClick={handleAddTransaction}>
              {editItem && 'amount' in editItem ? 'Simpan' : 'Tambah'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Category Dialog */}
      <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editItem && 'type' in editItem && !('amount' in editItem) ? 'Edit Kategori' : 'Tambah Kategori'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Tipe Kategori</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={categoryForm.type === 'income' ? 'default' : 'outline'}
                  className={cn("flex-1", categoryForm.type === 'income' && "bg-emerald-500 hover:bg-emerald-600")}
                  onClick={() => setCategoryForm({ ...categoryForm, type: 'income' })}
                >
                  Pemasukan
                </Button>
                <Button
                  type="button"
                  variant={categoryForm.type === 'expense' ? 'default' : 'outline'}
                  className={cn("flex-1", categoryForm.type === 'expense' && "bg-red-500 hover:bg-red-600")}
                  onClick={() => setCategoryForm({ ...categoryForm, type: 'expense' })}
                >
                  Pengeluaran
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="catName">Nama Kategori</Label>
              <Input
                id="catName"
                placeholder="Masukkan nama kategori"
                value={categoryForm.name}
                onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Warna</Label>
              <div className="flex flex-wrap gap-2">
                {categoryColors.map(color => (
                  <button
                    key={color}
                    type="button"
                    className={cn(
                      "w-8 h-8 rounded-full transition-transform",
                      color,
                      categoryForm.color === color && "ring-2 ring-offset-2 ring-gray-400 scale-110"
                    )}
                    onClick={() => setCategoryForm({ ...categoryForm, color })}
                  />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCategoryDialogOpen(false)}>Batal</Button>
            <Button onClick={handleAddCategory}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Account Dialog */}
      <Dialog open={accountDialogOpen} onOpenChange={setAccountDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editItem && 'balance' in editItem && !('amount' in editItem) ? 'Edit Akun' : 'Tambah Akun'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="accName">Nama Akun</Label>
              <Input
                id="accName"
                placeholder="Masukkan nama akun"
                value={accountForm.name}
                onChange={(e) => setAccountForm({ ...accountForm, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Tipe Akun</Label>
              <Select
                value={accountForm.type}
                onValueChange={(v) => setAccountForm({ ...accountForm, type: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Kas</SelectItem>
                  <SelectItem value="bank">Bank</SelectItem>
                  <SelectItem value="ewallet">E-Wallet</SelectItem>
                  <SelectItem value="credit_card">Kartu Kredit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="accBalance">Saldo Awal</Label>
              <Input
                id="accBalance"
                type="number"
                placeholder="0"
                value={accountForm.balance}
                onChange={(e) => setAccountForm({ ...accountForm, balance: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Warna</Label>
              <div className="flex flex-wrap gap-2">
                {categoryColors.map(color => (
                  <button
                    key={color}
                    type="button"
                    className={cn(
                      "w-8 h-8 rounded-full transition-transform",
                      color,
                      accountForm.color === color && "ring-2 ring-offset-2 ring-gray-400 scale-110"
                    )}
                    onClick={() => setAccountForm({ ...accountForm, color })}
                  />
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="accDesc">Deskripsi (Opsional)</Label>
              <Textarea
                id="accDesc"
                placeholder="Tambahkan deskripsi..."
                value={accountForm.description}
                onChange={(e) => setAccountForm({ ...accountForm, description: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAccountDialogOpen(false)}>Batal</Button>
            <Button onClick={handleAddAccount}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Budget Dialog */}
      <Dialog open={budgetDialogOpen} onOpenChange={setBudgetDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah Anggaran</DialogTitle>
            <DialogDescription>
              Anggaran untuk {getMonthName(currentMonth)} {currentYear}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Kategori</Label>
              <Select
                value={budgetForm.categoryId}
                onValueChange={(v) => setBudgetForm({ ...budgetForm, categoryId: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih kategori" />
                </SelectTrigger>
                <SelectContent>
                  {expenseCategories.map(cat => (
                    <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetAmount">Jumlah Anggaran (Rp)</Label>
              <Input
                id="budgetAmount"
                type="number"
                placeholder="0"
                value={budgetForm.amount}
                onChange={(e) => setBudgetForm({ ...budgetForm, amount: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBudgetDialogOpen(false)}>Batal</Button>
            <Button onClick={handleAddBudget}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Konfirmasi Hapus</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus data ini? Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
